<?php
include_once "connection.php";
include_once "navbar.php";
include_once "../functions.php";

if(isset($_POST["submit"])){
    $nameemail = $_POST["nameemail"]; /// Funkcia isset() overí, či premenná existuje a nie je null.
    $password = $_POST["password"];  ///slúži na overenie, či bola odoslaná určitá požiadavka pomocou metódy POST z formulára s názvom "submit".
    $result = mysqli_query($conn, "SELECT * FROM registration WHERE Meno = '$nameemail' OR email = '$nameemail'");
    $row = mysqli_fetch_assoc($result);
    if(mysqli_num_rows($result) > 0){ /// Zistovanie ci je uzivatel uz zaregistrovany
        if($password == $row['Heslo']){ ///Pokial podmienka platí, tak nás to presmeruje do adminskuska.php
            $_SESSION["login"] = true;

            header("Location: update.php");
        }
        else{ /// ak nie hodí alert chybu o hesle
            echo
            "<script> alert('Zlé heslo!'); </script>";
        }
    }
    else{
        echo /// Pokial nie je splnená prvá podmienka vyskočí nám alert
        "<script> alert('Nieste zaregistrovaný!'); </script>";
    }
}
///Metóda POST je jednou z možností, ako odoslať dáta z formulára na webovej stránke na server. Keď používateľ klikne na tlačidlo odoslať, všetky hodnoty polí vo formulári sa odosielajú na server v kóde HTTP požiadavky.
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Login</title>
</head>
<body>
<h2 class="col-md-12">Prihláste sa</h2>
<form class="col-md-4" action="" method="post" autocomplete="off">
    <label class="col-md-6" for="nameemail">Name or Email : </label>
    <input class="col-md-6" type="text" name="nameemail" id = "nameemail" required value=""> <br>
    <label class="col-md-6" for="password">Password : </label>
    <input class="col-md-6" type="password" name="password" id = "password" required value=""> <br>
    <div class="col-md-12"><button type="submit" name="submit">Prihlásiť sa</button></div>
    <br>
    <p class="col-md-10">Nieste zaregistrovaný? <a href="registration.php">Zaregistrujte sa!</a></p>
</form>
</body>
</html>