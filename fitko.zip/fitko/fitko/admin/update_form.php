<?php
include_once "navbar.php";
include_once "../functions.php";
$trainers = new Trainers();

$trainer = $trainers->getTrainerItem($_GET['id']);


?>
<form action="update.php" method="post">
    Name:<br>
    <input type="text" name="name" placeholder="name" value="<?php echo $trainer['name']; ?>"><br>
    Header:<br>
    <input type="text" name="header" placeholder="header" value="<?php echo $trainer['header']; ?>"><br>
    Text:<br>
    <input type="text" name="text" placeholder="text" value="<?php echo $trainer['text']; ?>"><br>
    Image:<br>
    <input type="text" name="image" placeholder="image" value="<?php echo $trainer['image']; ?>"><br>
    Link:<br>
    <input type="text" name="link" placeholder="link" value="<?php echo $trainer['link']; ?>"><br>
    Icon:<br>
    <input type="text" name="icon" placeholder="icon" value="<?php echo $trainer['icon']; ?>"><br>
    <input type="hidden" name="id" value="<?php echo $trainer['id']; ?>">
    <input type="submit" name="submit" value="Update">
</form>