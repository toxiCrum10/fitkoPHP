<?php

include_once "../functions.php";

if(isset($_POST['submit'])) {
$trainers = new Trainers();
$update = $trainers->updateTrainer(
    $_POST['id'],
    $_POST['image'],
    $_POST['header'],
    $_POST['text'],
    $_POST['name'],
    $_POST['link'],
    $_POST['icon']
);
if($update) {
header('Location: menu.php?status=2');
} else {
header('Location: menu.php?status=3');
}
} else {
header('Location: menu.php');
}