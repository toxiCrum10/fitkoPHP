<?php
include_once "../functions.php";


$trainers = new Trainers();

if(isset($_GET['id'])) {
$delete = $trainers->deleteTrainer($_GET['id']);
if($delete) {
header('Location: menu.php');
} else {
echo "Error";
}
} else {
header('Location: menu.php');
}