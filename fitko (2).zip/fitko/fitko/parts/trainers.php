

<?php

    include_once "functions.php";
    $trainers = new Trainers();
    $trainer = $trainers->getTrainersFromDatabase();

    $trainers->printTrainers($trainer);
