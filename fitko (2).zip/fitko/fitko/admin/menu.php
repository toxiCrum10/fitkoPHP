<?php
include_once "navbar.php";
include_once "../functions.php";
$trainers = new Trainers();
$arrayOfTrainers = $trainers->getTrainersFromDatabase();

if(isset($_GET['status']) && $_GET['status'] == 2) {
    echo "<strong>Value updated correctly</strong><br><br>";
} elseif (isset($_GET['status']) && $_GET['status'] == 3) {
    echo "<strong>Value cannot be updated</strong><br><br>";
}
?>


<ul>
    <?php
    foreach ($arrayOfTrainers as $menuItem) {

        echo "<li>ID: ". $menuItem['id'] . ", User name: " . $menuItem['name'] . "  " .
            '<a href="delete.php?id='.$menuItem['id'].'">Delete</a> /
             <a href="update_form.php?id='.$menuItem['id'].'">Update</a>
            </li>';

    }

    ?>
</ul>