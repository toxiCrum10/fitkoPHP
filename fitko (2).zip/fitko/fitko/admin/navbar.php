<a href="menu.php">Menu </a> / <a href="insert.php"> Insert </a>

