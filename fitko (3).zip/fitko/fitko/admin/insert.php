<?php
include_once "navbar.php";
include_once "../functions.php";
$trainers = new Trainers();

if (isset($_POST['submit'])) {
    $insert = $trainers->insertTrainer($_POST['name'], $_POST['header'], $_POST['text'], $_POST['image'], $_POST['link'],$_POST['icon']);
    if ($insert) {
        header('Location: insert.php?status=1');
    } else {
        echo 'Unable to insert values';
    }
} else {
    if(isset($_GET['status']) && $_GET['status'] == 1) {

        echo '<strong>value inserted</strong><br><br>';
    }


    ?>

    <form action="insert.php" method="post">
        Name:<br>
        <input type="text" name="name" placeholder="name" value=""><br>
        Header:<br>
        <input type="text" name="header" placeholder="header" value=""><br>
        Text:<br>
        <input type="text" name="text" placeholder="text" value=""><br>
        Image:<br>
        <input type="text" name="image" placeholder="image" value=""><br>
        Link:<br>
        <input type="text" name="link" placeholder="link" value=""><br>
        Icon:<br>
        <input type="text" name="icon" placeholder="icon" value=""><br>
        <input type="submit" name="submit" value="Create">
    </form>
    <?php
}
?>


