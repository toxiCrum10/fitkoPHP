<?php

class Trainers
{
    private string $hostname = "localhost";
    private int $port = 3306;
    private string $username = "root";
    private string $password = "";
    private string $dbName = "trainers";

    private $connection;


    public function __construct(string $host = "", int $port = 3306, string $user = "", string $pass = "", string $dbName = "")
    {
        if (!empty($host)) {
            $this->hostname = $host;
        }

        if (!empty($port)) {
            $this->port = $port;
        }

        if (!empty($user)) {
            $this->username = $user;
        }

        if (!empty($pass)) {
            $this->password = $pass;
        }

        if (!empty($dbName)) {
            $this->dbName = $dbName;
        }

        try {

            $this->connection = new PDO("mysql:charset=utf8;host=" . $this->hostname . ";dbname=" . $this->dbName . ";port=" . $this->port, $this->username, $this->password);
        } catch (\Exception $exception) {
            echo $exception->getMessage();
            die();
        }
    }


    public function getTrainersFromDatabase(): array
    {
        $menu = [];

        try {
            $sql = "SELECT * FROM trainer";
            $query = $this->connection->query($sql);
            $menuItems = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($menuItems as $menuItem) {

                $menu[$menuItem['id']] = [
                    'header' => $menuItem['header'],
                    'name' => $menuItem['name'],
                    'text' => $menuItem['text'],
                    'link' => $menuItem['link'],
                    'icon' => $menuItem['icon'],
                    'image' => $menuItem['image'],
                    'id' => $menuItem['id']
                ];
            }

        } catch (\Exception $exception) {

            echo $exception . 'Nieco sa pokazilo';
        }


        return $menu;
    }

    public function printTrainers($menu)
    {

        foreach ($menu as $value) {


            echo '<div class="col-lg-4">
                    <div class="trainer-item">
                        <div class="image-thumb">
                            <img src="assets/images/' . $value['image'] . '" alt="">
                        </div>
                        <div class="down-content">
                            <span>' . $value['header'] . '</span>
                            <h4>' . $value['name'] . '</h4>
                            <p>' . $value['text'] . '</p>
                            <ul class="social-icons">
                                <li><a href="' . $value['link'] . '"><i class="fa fa-' . $value['icon'] . '"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>';
        }
    }

    public function updateTrainer(int $id, string $image, string $header, string $text, string $name, string $link, string $icon): bool
    {
        try {
            $sql = "UPDATE trainer SET image = :image, header = :header, text = :text, link = :link, name = :name, icon = :icon WHERE id = :id";
            $statement = $this->connection->prepare($sql);
            $statement->bindValue('id', $id);
            $statement->bindValue('image', $image);
            $statement->bindValue('header', $header);
            $statement->bindValue('text', $text);
            $statement->bindValue('link', $link);
            $statement->bindValue('name', $name);
            $statement->bindValue('icon', $icon);
            $update = $statement->execute();

        } catch (\Exception $exception) {
            $update = false;
        }

        return $update;
    }

    public function getTrainerItem(string $id): array
    {
        try {
            $sql = "SELECT * FROM trainer WHERE id = " . $id;
            $query = $this->connection->query($sql);
            $data = $query->fetch(PDO::FETCH_ASSOC);

            return $data;
        } catch (\Exception $exception) {
            return [];
        }
    }

    public function insertTrainer(string $name, string $header, string $text, string $image, string $link, string $icon): bool
    {
        $insert = false;
        $sql = "INSERT INTO trainer(name, header, text, image, link, icon) VALUE('".$name."', '".$header."', '".$text."', '".$image."','".$link."','".$icon."') ";
        try {
            $statement = $this->connection->prepare($sql);
            $insert = $statement->execute();


        } catch (\Exception $exception) {
            echo "Unable to insert value. Error" . $exception->getMessage();
        }

        return $insert;
    }

    public function deleteTrainer(string $id): bool
    {
        $delete = false;
        $sql = "DELETE FROM trainer WHERE id = ".$id;

        try {
            $statement = $this->connection->prepare($sql);
            $delete = $statement->execute();
        } catch (\Exception $exception) {
            echo "Unable to delete value. Error: " . $exception->getMessage();
        }

        return $delete;
    }


}